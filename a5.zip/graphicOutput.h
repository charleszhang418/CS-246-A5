#ifndef _GRAPHICOUTPUT_H_
#define _GRAPHICOUTPUT_H_

#include "window.h"

